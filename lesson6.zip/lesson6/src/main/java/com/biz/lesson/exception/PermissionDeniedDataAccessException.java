package com.biz.lesson.exception;

public class PermissionDeniedDataAccessException extends RuntimeException  {

    private static final long serialVersionUID = 2564364488064475347L;

}
