package com.biz.lesson.dao.student;

import com.biz.lesson.model.student.Grade;
import com.biz.lesson.model.student.Student;
import com.biz.lesson.model.student.Subject;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 *
 **/
public interface StudentRepository extends Repository<Student,Integer> {




    public  Student findByName(String name);

    public List<Student> findByCodeStartingWith(String code);

    public List<Student> findByBirthdayBetween(Date lastBirthday,Date nextBirthday);

    @Query(nativeQuery = true,
     value = "select count(sub.name) from (student stu left join student_subject ss on stu.id = ss.student_id left join subject sub on ss.subject_id = sub.id ) group by stu.id;")
    public List<BigInteger> getSubjectById();

    @Query(nativeQuery = true,
            value = "select AVG(sub.score) from (student stu left join student_subject ss on stu.id = ss.student_id left join subject sub on ss.subject_id = sub.id ) group by stu.id;")
    public List<BigDecimal> getSubjectAvgScore();

    //where name like ?% and age <?
    //public List<Student> findByNameStartingWithAndAgeLessThan(String name, Integer age);
    //where name like %? and age <?
    //public List<Student> findByNameEndingWithAndAgeLessThan(String name, Integer age);
    //where name in (? ? ?) or age <?
    //public List<Student> findByNameInOrAgeLessThan(List<String> nameList, Integer age);
    //where name in (? ? ?) And age <?
    //public List<Student> findByNameInAndAgeLessThan(List<String> nameList, Integer age);

    //@Query("select s from Student s where s.id=(select max(id) from Student) ")
    @Query("select s from Student s where s.id= ?1 ")
    public  Student getStudentById(Integer id);

    @Query("select g.gradeName from Grade g group by g.gradeName")
    public  List<String> getGradeName();

    @Query(nativeQuery = true,value = "select count(stu.id) from Grade g\n" +
            "left join Student stu\n" +
            "on stu.grade_gradeid=g.gradeid \n" +
            "group by g.gradename")
    public  List<BigInteger> getstudentNum();

    @Query(nativeQuery = true,value = "select avg(sub.score) from Grade g \n" +
            "left join Student stu \n" +
            "on stu.grade_gradeId=g.gradeId \n" +
            "left join student_subject  ss\n" +
            "on stu.id=ss.student_id\n" +
            "left join  Subject sub \n" +
            "on sub.id = ss.subject_id\n" +
            "group by g.gradeName")
    public  List<BigDecimal> getStudentAvgScore();

    @Query("select sub.name from Subject sub group by sub.name")
    public  List<String> getSubjectName();

    @Query(nativeQuery = true,value = "select count(stu.id) from subject sub \n" +
            "left join student_subject ss\n" +
            "on sub.id = ss.subject_id\n" +
            "left join student stu\n" +
            "on stu.id = ss.student_id\n" +
            "group by sub.name")
    public  List<BigInteger> getSubjectNum();

    @Query(nativeQuery = true,value = "select avg(sub.score) from subject sub \n" +
            "left join student_subject ss\n" +
            "on sub.id = ss.subject_id\n" +
            "left join student stu\n" +
            "on stu.id = ss.student_id\n" +
            "left join Grade g\n" +
            "on g.gradeid = stu.grade_gradeid\n" +
            "group by sub.name")
    public  List<BigDecimal> getSubjectSubjectAvgScore();

    @Query(nativeQuery = true,value ="select stu.* from (Student stu\n" +
            "left join grade g\n" +
            "on stu.grade_gradeid=g.gradeid\n" +
            "left join student_subject ss\n" +
            "on stu.id = ss.student_id\n" +
            "right join subject sub\n" +
            "on sub.id= ss.subject_id)\n" +
            "where gradename =?1")
    public List<Student> getStudentsByGradeName(String name);
    @Query(nativeQuery = true,value ="select sub.id from (subject sub\n" +
            "left join student_subject ss\n" +
            "on sub.id = ss.subject_id \n" +
            "left join student stu\n" +
            "on stu.id =ss.student_id)\n" +
            "where stu.id =?1")
    public List<Integer> getSubjectByStudentId(Integer id);

    @Query("select e from Student e where e.name=?1 and e.id=?2")
    public  List<Student> queryParamsl(String name,Integer id);

    @Query("select e from Student e where e.name=:name and e.id=:id")
    public  List<Student> queryParams2(@Param("name") String name, @Param("id") Integer id);


    @Query("select e from Student e where e.name like %?1% ")
    public  List<Student> queryLike1(String name);

    @Query("select e from Student e where e.name like %:userName% ")
    public  List<Student> queryLike2(@Param("userName") String name);

    //employee为表
    @Query(nativeQuery = true,value = "select count(1) from student")
    public  long getCount();


    @Query(nativeQuery = true,
            value = "select g.gradeid from grade g\n" +
            "left join student stu\n" +
            "on g.gradeid =stu.grade_gradeid\n" +
            "where stu.id=?1")
    public  Integer queryStudentGrade_id(@Param("id")Integer id);

    @Modifying
    @Query("update Student set code =:code," +
            "name = :name,birthday = :birthday,sex =:sex where id = :id")
    public void updateStudent(@Param("code") String code,
                              @Param("name") String name,
                              @Param("birthday") Date birthday,
                              /*@Param("grade") Grade grade,*/
                              @Param("sex") String sex,
                              @Param("id") Integer id);

    @Query("select s from Subject s where s.name= ?1 ")
    public  Subject getSubjectByName(String name);

    @Modifying
    @Query("update Grade set gradeName = :name where gradeId = :id")
    public void updateGrade(@Param("id") Integer id,@Param("name") String name);

    @Modifying
    @Query("update Student set name = :name where id = :id")
    public void update(@Param("id") Integer id,@Param("name") String name);

    @Modifying
    @Query("update Student set name = ?2 where id = ?1")
    public void update1(Integer id,String name);

    @Modifying
    @Query("delete  from Student where id = :id")
    public void  deleteStudentById(@Param("id") Integer id);

    @Modifying
    @Query("delete  from Student where id = ?1")
    public void  deleteById1(Integer id);


    @Modifying
    @Query("delete  from Subject where id = :id")
    public void  deleteSubjectById(@Param("id") Integer id);

    @Modifying
    @Query("delete  from Grade where gradeName = ?1")
    public void  deleteGradeByName(String name);
    @Modifying
    @Query("delete  from Subject where subjectName = ?1")
    public void  deleteSubjectByName(String name);

}

