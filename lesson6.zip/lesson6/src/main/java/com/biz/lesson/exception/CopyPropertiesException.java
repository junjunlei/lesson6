package com.biz.lesson.exception;

public class CopyPropertiesException extends RuntimeException {

    private static final long serialVersionUID = -3611152660417280494L;

    public CopyPropertiesException(Exception e) {
        super(e);
    }


    
    
}
