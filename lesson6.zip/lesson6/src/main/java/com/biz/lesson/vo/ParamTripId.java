package com.biz.lesson.vo;

public interface ParamTripId {
    
    String getTripId();
}
