package com.biz.lesson;

public final class CacheConstants {

    /**
     * 系统配置
     */
    public static final String CONFIG = "config";


    /**
     * 用户
     */
    public static final String USERS = "cache_all_users";
}
