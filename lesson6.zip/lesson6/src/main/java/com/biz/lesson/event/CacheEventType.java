package com.biz.lesson.event;

/**
 *  缓存事件类型
 */
public enum CacheEventType {

    USER,
	CONFIG;

}
