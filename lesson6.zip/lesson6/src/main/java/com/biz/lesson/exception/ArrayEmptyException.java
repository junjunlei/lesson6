package com.biz.lesson.exception;

public class ArrayEmptyException extends RuntimeException {

    private static final long serialVersionUID = 3283618842915686646L;

    public ArrayEmptyException() {
        super();
    }

    
    

}
