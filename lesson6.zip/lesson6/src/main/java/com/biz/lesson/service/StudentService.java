package com.biz.lesson.service;


import com.biz.lesson.dao.student.*;
import com.biz.lesson.model.student.Grade;
import com.biz.lesson.model.student.Student;
import com.biz.lesson.model.student.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private StudentCrudRepository studentCrudRepository;
    @Autowired
    private GradeCrudRepository gradeCrudRepository;
    @Autowired
    private SubjectCrudRepository subjectCrudRepository;
    @Autowired
    private StudentJpaRepository studentJpaRepository;
    @Autowired
    private StudentPagingAndSortingRepository studentPagingAndSortingRepository;
    @Transactional
    public void update(Integer id,String name){
        studentRepository.update(id,name);
    }
    @Transactional
    public void updateStudent(Student student){
        studentRepository.updateStudent(student.getCode(),student.getName(),student.getBirthday(),student.getSex(),student.getId());
    }
    @Transactional
    public  Integer queryStudentGrade_id(Integer id){
        return studentRepository.queryStudentGrade_id(id);
    }
    @Transactional
    public void updateGrade(Integer id, String name){
        studentRepository.updateGrade(id,name);
    }
    @Transactional
    public void update1(Integer id,String name){
        studentRepository.update1(id,name);
    }
    @Transactional
    public void deleteStudentById(Integer id){
        studentRepository.deleteStudentById(id);
    }
    @Transactional
    public void deleteSubjectById(Integer id){
        studentRepository.deleteSubjectById(id);
    }
    @Transactional
    public void deleteById1(Integer id){
        studentRepository.deleteById1(id);
    }
    @Transactional
    public void deleteSubjectByName(String subjectName){
        studentRepository.deleteGradeByName(subjectName);
    }
    @Transactional
    public void deleteGradeByName(String gradeName){
        studentRepository.deleteGradeByName(gradeName);
    }

    @Transactional
    public  void  save(List<Student> students){
        studentCrudRepository.save(students);
    }

    @Transactional
    public void saveGrade(Grade grade){
        gradeCrudRepository.save(grade);
    }
    @Transactional
    public void saveSubject(Subject subject){
        subjectCrudRepository.save(subject);
    }
    @Transactional
    public  void  deleteAll(){
        studentCrudRepository.deleteAll();
    }

    public List<Student> findAll() {
        List<Student> studentList = studentJpaRepository.findAll();
        return studentList;
    }
    public Page<Student> pageList(Integer number) {
        Pageable pageable = new PageRequest(number,10    );
        Page<Student> page = studentPagingAndSortingRepository.findAll(pageable);

        System.out.println("getTotalElements--查询的总记录数:"+page.getTotalElements());
        System.out.println("getTotalPages--查询的总页数:"+page.getTotalPages());
        System.out.println("getContent--当前页面的集合："+page.getContent());
        System.out.println("getNumber--当前第几页:"+page.getNumber() + 1);
        System.out.println("getNumberOfElements--查询的当前页面的记录数:"+page.getNumberOfElements());
        return page;
    }
    public List<Student> searchByName(String name){
        return studentRepository.queryLike1(name);
    }
    public List<Student> findByCodeStartWith(String code){
        return studentRepository.findByCodeStartingWith(code);
    }

    public List<Student> searchBirthday(String birthday){
        List<Student> students = studentJpaRepository.findAll();
        List<Student> studentList = new ArrayList<Student>();
        for (Student student:students) {
            Date date = student.getBirthday();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String formatBirthday = sdf.format(date);
            if(formatBirthday.equals(birthday)){
                studentList.add(student);
            }
        }
            return studentList;
    }

    public List<Student> findByBirthdayBetween(Date lastBirthday,Date nextBirthday){
        return  studentRepository.findByBirthdayBetween(lastBirthday,nextBirthday);
    }
    public List<BigInteger> getSubjectById(){
        return studentRepository.getSubjectById();
    }

    public List<BigDecimal> getSubjectAvgScore(){
        List<BigDecimal> AvgScoreList = studentRepository.getSubjectAvgScore();
        for(int i= 0;i<AvgScoreList.size();i++){
            System.out.println(AvgScoreList.size()+"AvgScore1---------------->"+ AvgScoreList.get(i));
            BigDecimal  AvgScore=AvgScoreList.get(i);
            if(AvgScore == null){
                AvgScore = BigDecimal.valueOf(0).setScale(1,BigDecimal.ROUND_HALF_UP);
                AvgScoreList.remove(i);
                AvgScoreList.add(i,AvgScore);
            }else {
                AvgScore=AvgScoreList.get(i).setScale(1,BigDecimal.ROUND_HALF_UP);
                AvgScoreList.remove(i);
                AvgScoreList.add(i,AvgScore);
            }
        }
        for(int i= 0;i<AvgScoreList.size();i++){
            BigDecimal  AvgScore=AvgScoreList.get(i);
            System.out.println(AvgScoreList.size()+"AvgScore2----------------<>"+AvgScore);
        }
        return AvgScoreList;

    }

    public Student getStudentById(Integer id){
        return studentRepository.getStudentById(id);
    }

    public  List<String> getGradeName(){
        List<String> strings =  studentRepository.getGradeName();
        return strings;
    }

    public  List<BigInteger> getstudentNum(){
        List<BigInteger> integerList = studentRepository.getstudentNum();
        return integerList;
    }

    public  List<BigDecimal> getStudentAvgScore(){
        List<BigDecimal> StudentAvgScore = studentRepository.getStudentAvgScore();
        for(int i= 0;i<StudentAvgScore.size();i++){
            System.out.println(StudentAvgScore.size()+"StudentAvgScore------1---------->"+ StudentAvgScore.get(i));
            BigDecimal  AvgScore=StudentAvgScore.get(i);
            if(AvgScore == null){
                AvgScore = BigDecimal.valueOf(0).setScale(1,BigDecimal.ROUND_HALF_UP);
                StudentAvgScore.remove(i);
                StudentAvgScore.add(i,AvgScore);
            }else {
                AvgScore=StudentAvgScore.get(i).setScale(1,BigDecimal.ROUND_HALF_UP);
                StudentAvgScore.remove(i);
                StudentAvgScore.add(i,AvgScore);
            }
        }
        return StudentAvgScore;
    }
    public  List<String> getSubjectName(){
        return studentRepository.getSubjectName();
    }
    public  List<BigInteger> getSubjectNum(){
        return studentRepository.getSubjectNum();
    }
    public  List<BigDecimal> getSubjectSubjectAvgScore(){
        List<BigDecimal> StudentSubjectAvgScore = studentRepository.getSubjectSubjectAvgScore();
        for(int i= 0;i<StudentSubjectAvgScore.size();i++){
            System.out.println(StudentSubjectAvgScore.size()+"StudentAvgScore------1---------->"+ StudentSubjectAvgScore.get(i));
            BigDecimal  AvgScore=StudentSubjectAvgScore.get(i);
            if(AvgScore == null){
                AvgScore = BigDecimal.valueOf(0).setScale(1,BigDecimal.ROUND_HALF_UP);
                StudentSubjectAvgScore.remove(i);
                StudentSubjectAvgScore.add(i,AvgScore);
            }else {
                AvgScore=StudentSubjectAvgScore.get(i).setScale(1,BigDecimal.ROUND_HALF_UP);
                StudentSubjectAvgScore.remove(i);
                StudentSubjectAvgScore.add(i,AvgScore);
            }
        }
        return StudentSubjectAvgScore;
    }

    public List<Student> getStudentsByGradeName(String name){
        return studentRepository.getStudentsByGradeName(name);

    }
    public List<Integer> getSubjectByStudentId(Integer id){
        return studentRepository.getSubjectByStudentId(id);

    }




}
