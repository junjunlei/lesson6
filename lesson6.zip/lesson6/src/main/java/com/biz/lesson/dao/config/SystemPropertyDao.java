package com.biz.lesson.dao.config;


public interface SystemPropertyDao {

}
