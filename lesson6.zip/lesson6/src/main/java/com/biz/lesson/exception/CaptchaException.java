package com.biz.lesson.exception;

public class CaptchaException extends RuntimeException {

    private static final long serialVersionUID = 8735869253711609037L;

}
