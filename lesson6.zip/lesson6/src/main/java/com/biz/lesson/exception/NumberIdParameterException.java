package com.biz.lesson.exception;

public class NumberIdParameterException extends RuntimeException {

    private static final long serialVersionUID = 2578751715394660434L;
    

    public NumberIdParameterException() {
        super();
    }
    
}
