package com.biz.lesson.service;

import com.biz.lesson.dao.student.GradeCrudRepository;
import com.biz.lesson.dao.student.GradeRepository;
import com.biz.lesson.dao.student.SubjectCrudRepository;
import com.biz.lesson.dao.student.SubjectRepository;
import com.biz.lesson.model.student.Grade;
import com.biz.lesson.model.student.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/**
 * 学科管理
 **/
@Service
public class SubjectService {

    @Autowired
    private SubjectRepository subjectRepository;

    @Autowired
    private SubjectCrudRepository subjectCrudRepository;

    @Transactional
    public void save(List<Subject> subjectList){
        subjectCrudRepository.save(subjectList);
    }
    @Transactional
    public void save(Subject subject){
        subjectCrudRepository.save(subject);
    }

    @Transactional
    public void deleteAll(){
        subjectCrudRepository.deleteAll();
    }

    @Transactional
    public void saveSubject(Subject subject){
        subjectCrudRepository.save(subject);
    }

}
