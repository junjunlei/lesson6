package com.biz.lesson.model;

import com.biz.lesson.model.base.Name;

public interface Named {
	Name getName();
}
