package com.biz.lesson.dao.student;

import com.biz.lesson.model.student.Subject;
import org.springframework.data.repository.Repository;

/**
 *
 **/
public interface SubjectRepository extends Repository<Subject,Integer> {

    public Subject findByName(String Name);
}
