package com.biz.lesson.exception;


public class UserNotLoginException extends RuntimeException {

    private static final long serialVersionUID = 36706868616772169L;


}
