package com.biz.lesson.vo.user;

import java.sql.Date;

public interface SearchLoginLog {

	public String getUserId() ;
	public Date getFromDate() ;
	public Date getToDate() ;
}
