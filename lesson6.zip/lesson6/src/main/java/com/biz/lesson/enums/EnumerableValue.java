package com.biz.lesson.enums;


public interface EnumerableValue{
	
	int getValue();

	
}
