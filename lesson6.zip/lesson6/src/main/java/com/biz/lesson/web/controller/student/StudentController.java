package com.biz.lesson.web.controller.student;

import com.biz.lesson.model.base.Name;
import com.biz.lesson.model.student.Grade;
import com.biz.lesson.model.student.Student;
import com.biz.lesson.model.student.Subject;
import com.biz.lesson.service.GradeService;
import com.biz.lesson.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *学生、班级、学科
 **/
@Controller
@RequestMapping("student")
public class StudentController {

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private StudentService studentService;

    @Autowired
    private GradeService gradeService;

    private ModelAndView modelAndView = new ModelAndView();

    @RequestMapping("studentMessage")
    public ModelAndView showList(){
        /*List<Student> studentList = studentService.findAll();
        for (Student student: studentList) {
            System.out.println("--------------"+student);
        }*/
        Integer number = 0;
        Page<Student> pageList = studentService.pageList(number);
        List<Student> studentList = pageList.getContent();
        System.out.println("getTotalElements--查询的总记录数:"+pageList.getTotalElements());
        System.out.println("getTotalPages--查询的总页数:"+pageList.getTotalPages());
        System.out.println("getContent--当前页面的集合："+pageList.getContent());
        System.out.println("getNumber--当前第几页:"+pageList.getNumber() + 1);
        System.out.println("getNumberOfElements--查询的当前页面的记录数:"+pageList.getNumberOfElements());

        List<BigInteger> subjectCount = studentService.getSubjectById();
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        for (BigInteger  count:subjectCount) {
            System.out.println("count---------------->"+count.intValue());
        }
        request.setAttribute("TotalElements",pageList.getTotalElements());
        request.setAttribute("TotalPages",pageList.getTotalPages());
        request.setAttribute("Number",pageList.getNumber());
        request.setAttribute("NumberOfElements",pageList.getNumberOfElements());
        request.setAttribute("studentList",studentList);
        modelAndView.setViewName("student/studentMessage");
        return modelAndView;
    }
    @RequestMapping("studentMessagePage")
    public ModelAndView pageList(){
        /*List<Student> studentList = studentService.findAll();
        for (Student student: studentList) {
            System.out.println("--------------"+student);
        }*/
        Integer number = Integer.parseInt(request.getParameter("Number"));
        if(number < 0){
            number =0;
        }
        System.out.println("--------number-------"+number);
        Page<Student> pageList = studentService.pageList(number);
        List<BigInteger> subjectCount = studentService.getSubjectById();
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        int pageSize = 10;//每页总数为10条
        if (number >= (pageList.getTotalPages()-1)){
            pageList = studentService.pageList(pageList.getTotalPages()-1);
            subjectCount = studentService.getSubjectById().subList(number*pageSize,subjectCount.size());
            AvgScoreList = studentService.getSubjectAvgScore().subList(number*pageSize,AvgScoreList.size());
        }else {
            subjectCount = studentService.getSubjectById().subList(number * pageSize, (number + 1) * pageSize);
            AvgScoreList = studentService.getSubjectAvgScore().subList(number * pageSize, (number + 1) * pageSize);
        }
        List<Student> studentList = pageList.getContent();
        System.out.println("getTotalElements--查询的总记录数:"+pageList.getTotalElements());
        System.out.println("getTotalPages--查询的总页数:"+pageList.getTotalPages());
        System.out.println("getContent--当前页面的集合："+pageList.getContent());
        System.out.println("getNumber--当前第几页:"+pageList.getNumber() + 1);
        System.out.println("getNumberOfElements--查询的当前页面的记录数:"+pageList.getNumberOfElements());
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        request.setAttribute("TotalElements",pageList.getTotalElements());
        request.setAttribute("TotalPages",pageList.getTotalPages());
        request.setAttribute("Number",pageList.getNumber());
        request.setAttribute("NumberOfElements",pageList.getNumberOfElements());
        request.setAttribute("studentList",studentList);
        modelAndView.setViewName("student/studentMessage");
        return modelAndView;
    }
    /*@RequestMapping("getNumberPage")
    public ModelAndView pageNumberList(){

        Integer number = Integer.parseInt(request.getParameter("number"));
        if(number < 0){
            number =0;
        }
        System.out.println("--------number-------"+number);
        Page<Student> pageList = studentService.pageList(number);
        if (number >= pageList.getTotalPages()){
            pageList = studentService.pageList(pageList.getTotalPages()-1);
        }
        List<Student> studentList = pageList.getContent();
        System.out.println("getTotalElements--查询的总记录数:"+pageList.getTotalElements());
        System.out.println("getTotalPages--查询的总页数:"+pageList.getTotalPages());
        System.out.println("getContent--当前页面的集合："+pageList.getContent());
        System.out.println("getNumber--当前第几页:"+pageList.getNumber() + 1);
        System.out.println("getNumberOfElements--查询的当前页面的记录数:"+pageList.getNumberOfElements());

        request.setAttribute("TotalElements",pageList.getTotalElements());
        request.setAttribute("TotalPages",pageList.getTotalPages());
        request.setAttribute("Number",pageList.getNumber());
        request.setAttribute("NumberOfElements",pageList.getNumberOfElements());
        request.setAttribute("studentList",studentList);
        modelAndView.setViewName("studentMessage");
        return modelAndView;
    }*/
    @RequestMapping("SearchCode")
    public ModelAndView searchCode() throws ServletException, IOException {
        String code = request.getParameter("code");
        List<Student> studentList = studentService.findByCodeStartWith(code);
        System.out.println("--------------------------"+studentList.size()+"===============");
        if((studentList.size())!=0){

            for (Student student : studentList) {
                System.out.println(student + "----------------lx----------");
            }
            Integer currentPage = 0;
            int NumberOfElements = 0;//当前页有几条信息
            int TotalPages = 0;//页数
            int pageSize = 10;//每页总数为10条
            int TotalElements = studentList.size();
            int total = TotalElements % pageSize;
            if (total > 0) {
                TotalPages = TotalElements / pageSize + 1;
            } else {
                TotalPages = TotalElements / pageSize;
            }
            if(total == 0){
                if(TotalPages == 0){
                    studentList = null;
                }else {
                studentList = studentList.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
                }
            }else{
                if(TotalElements > pageSize){
                studentList = studentList.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
                }else {
                studentList = studentList.subList(currentPage,TotalElements);
                }
            }
        NumberOfElements = studentList.size();
        List<BigInteger> subjectCount = studentService.getSubjectById();
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        request.setAttribute("code", code);
        request.setAttribute("NumberOfElements", NumberOfElements);
        request.setAttribute("TotalPages", TotalPages);
        request.setAttribute("TotalElements", TotalElements);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("studentList", studentList);
        }else {
            studentList =null;
            Integer currentPage = 0;
            int NumberOfElements = 0;//当前页有几条信息
            int TotalPages = 0;//页数
            int pageSize = 10;//每页总数为10条
            int TotalElements = studentList.size();

            List<BigInteger> subjectCount = null;
            List<BigDecimal> AvgScoreList = null;
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        request.setAttribute("code", code);
        request.setAttribute("NumberOfElements", NumberOfElements);
        request.setAttribute("TotalPages", TotalPages);
        request.setAttribute("TotalElements", TotalElements);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("studentList", studentList);
        }

                modelAndView.setViewName("student/studentCode");
                return modelAndView;
    }
    @RequestMapping("SearchCodePage")
    public ModelAndView searchCodePage() throws ServletException, IOException {
        String code = request.getParameter("code");
            System.out.println(code + "--code--------------lx----------");
        List<Student> studentList1 = studentService.findByCodeStartWith(code);
        List<Student> studentList = null;
        Integer currentPage = Integer.parseInt(request.getParameter("currentPage"));
            System.out.println(currentPage + "--currentPage--------------lx----------");
        int NumberOfElements = 0;//当前页有几条信息
        int TotalPages = 0;//页数
        int pageSize = 10;//每页总数为10条
        int TotalElements = studentList1.size();
        int total = TotalElements % pageSize;
        System.out.println(total+"-<--------total-----------TotalElements---------->----"+TotalElements);
        if (total > 0) {
            TotalPages = TotalElements/pageSize + 1;
        } else {
            TotalPages = TotalElements/pageSize;
        }
        System.out.println("TotalPages---------------"+TotalPages);
        List<BigInteger> subjectCount = studentService.getSubjectById();
        request.setAttribute("subjectCount",subjectCount);
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        request.setAttribute("AvgScoreList",AvgScoreList);
        for (int j = 1; j <= TotalPages; j++) {
            if (total == 0) {
                if (currentPage <= 0) {
                    currentPage = 0;
                    studentList = studentList1.subList((0) * pageSize, pageSize * (0 + 1));
                    for (Student student : studentList1) {
                        System.out.println(student + "----------------lx----------");
                    }
                    System.out.println("------------------<=0-------------------");
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("code", code);
                    modelAndView.setViewName("student/studentMessageSearchPage");
                }
                if (currentPage >= TotalPages) {
                    studentList = studentList1.subList((currentPage - 1) * pageSize, TotalElements);
                    currentPage = TotalPages - 1;
                    System.out.println("currentPage=pageCount-1;" + currentPage + "/////" + TotalPages);
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("code", code);
                    modelAndView.setViewName("student/studentMessageSearchPage");

                }
                if (0 < currentPage && currentPage < TotalPages) {
                    studentList = studentList1.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("code", code);
                    modelAndView.setViewName("student/studentMessageSearchPage");

                }
            }else {
                if(currentPage<=0) {
                    currentPage=0;
                    if((currentPage+1) == TotalPages){
                        studentList = studentList1.subList(currentPage,TotalElements);
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("code", code);
                        modelAndView.setViewName("student/studentMessageSearchPage");
                    }else {
                    studentList = studentList1.subList((0)* pageSize, pageSize*(0+1));
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("code", code);
                    modelAndView.setViewName("student/studentMessageSearchPage");
                    }
                }
                if(currentPage>=TotalPages){
                    studentList = studentList1.subList((currentPage-1)* pageSize, TotalElements);
                    currentPage=TotalPages-1;
                    System.out.println("currentPage=pageCount-1;"+currentPage+"/////"+TotalPages);
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("code", code);
                    modelAndView.setViewName("student/studentMessageSearchPage");
                }
                if(0<currentPage&&currentPage<TotalPages) {
                    if(currentPage == (TotalPages-1)){

                    studentList = studentList1.subList((currentPage)* pageSize,TotalElements);
                    System.out.println(studentList+"--------------2");
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                        request.setAttribute("code", code);
                    modelAndView.setViewName("student/studentMessageSearchPage");
                    }else{
                    studentList = studentList1.subList((currentPage-1)* pageSize, (currentPage)* pageSize);
                    System.out.println(studentList+"--------------2");
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                        request.setAttribute("code", code);
                    modelAndView.setViewName("student/studentMessageSearchPage");

                    }

                }
            }
            }
                return modelAndView;
    }

    @RequestMapping("SearchName")
    public ModelAndView searchName(){
        String name = request.getParameter("name");
        List<Student> studentList = studentService.searchByName(name);

        Integer currentPage = 0;
        int NumberOfElements = 0;//当前页有几条信息
        int TotalPages = 0;//页数
        int pageSize = 10;//每页总数为10条
        int TotalElements = studentList.size();
        int total = TotalElements % pageSize;
        if (total > 0) {
            TotalPages = TotalElements / pageSize + 1;
        } else {
            TotalPages = TotalElements / pageSize;
        }
        if(total == 0){
            if(TotalPages == 0){
                studentList = null;
            }else {
                studentList = studentList.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
            }
        }else{
            if(TotalElements > pageSize){
                studentList = studentList.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
            }else {
                studentList = studentList.subList(currentPage,TotalElements);
            }
        }
        /*for (Student student : studentList) {
            System.out.println(student + "----------------lx----------");
        }*/
        NumberOfElements = studentList.size();
        List<BigInteger> subjectCount = studentService.getSubjectById();
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        request.setAttribute("name", name);
        request.setAttribute("NumberOfElements", NumberOfElements);
        request.setAttribute("TotalPages", TotalPages);
        request.setAttribute("TotalElements", TotalElements);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("studentList", studentList);

        modelAndView.setViewName("student/studentName");
        return modelAndView;
    }

    @RequestMapping("SearchNamePage")
    public ModelAndView searchNamePage(){
        String name = request.getParameter("name");
        System.out.println(name + "--name--------------lx----------");
        List<Student> studentList1 = studentService.searchByName(name);
        List<Student> studentList = null;
        Integer currentPage = Integer.parseInt(request.getParameter("currentPage"));
        System.out.println(currentPage + "--currentPage--------------lx----------");
        int NumberOfElements = 0;//当前页有几条信息
        int TotalPages = 0;//页数
        int pageSize = 10;//每页总数为10条
        int TotalElements = studentList1.size();
        int total = TotalElements % pageSize;
        System.out.println(total+"-<--------total-----------TotalElements---------->----"+TotalElements);
        if (total > 0) {
            TotalPages = TotalElements/pageSize + 1;
        } else {
            TotalPages = TotalElements/pageSize;
        }
        System.out.println("TotalPages---------------"+TotalPages);
        List<BigInteger> subjectCount = studentService.getSubjectById();
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        for (int j = 1; j <= TotalPages; j++) {
            if (total == 0) {
                if (currentPage <= 0) {
                    currentPage = 0;
                    studentList = studentList1.subList((0) * pageSize, pageSize * (0 + 1));
                    for (Student student : studentList1) {
                        System.out.println(student + "----------------lx----------");
                    }
                    System.out.println("------------------<=0-------------------");
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("name", name);
                    modelAndView.setViewName("student/studentNameSearchPage");
                }
                if (currentPage >= TotalPages) {
                    studentList = studentList1.subList((currentPage - 1) * pageSize, TotalElements);
                    currentPage = TotalPages - 1;
                    System.out.println("currentPage=pageCount-1;" + currentPage + "/////" + TotalPages);
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("name", name);
                    modelAndView.setViewName("student/studentNameSearchPage");

                }
                if (0 < currentPage && currentPage < TotalPages) {
                    studentList = studentList1.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("name", name);
                    modelAndView.setViewName("student/studentNameSearchPage");

                }
            }else {
                if(currentPage<=0) {
                    currentPage=0;
                    if((currentPage+1) == TotalPages){
                        studentList = studentList1.subList(currentPage,TotalElements);
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("name", name);
                        modelAndView.setViewName("student/studentNameSearchPage");
                    }else {
                        studentList = studentList1.subList((0)* pageSize, pageSize*(0+1));
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("name", name);
                        modelAndView.setViewName("student/studentNameSearchPage");
                    }
                }
                if(currentPage>=TotalPages){
                    studentList = studentList1.subList((currentPage-1)* pageSize, TotalElements);
                    currentPage=TotalPages-1;
                    System.out.println("currentPage=pageCount-1;"+currentPage+"/////"+TotalPages);
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("name", name);
                    modelAndView.setViewName("student/studentNameSearchPage");
                }
                if(0<currentPage&&currentPage<TotalPages) {
                    if(currentPage == (TotalPages-1)){

                        studentList = studentList1.subList((currentPage)* pageSize,TotalElements);
                        System.out.println(studentList+"--------------2");
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("name", name);
                        modelAndView.setViewName("student/studentNameSearchPage");
                    }else{
                        studentList = studentList1.subList((currentPage-1)* pageSize, (currentPage)* pageSize);
                        System.out.println(studentList+"--------------2");
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("name", name);
                        modelAndView.setViewName("student/studentNameSearchPage");

                    }

                }
            }
        }

        return modelAndView;
    }

    @RequestMapping("SearchBirthday")
    public ModelAndView searchBirthday(){
        String lastBirthday = request.getParameter("lastBirthday");
        String nextBirthday = request.getParameter("nextBirthday");
        System.out.println("------------------->>"+lastBirthday);
        System.out.println("------------------->>"+nextBirthday);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //SimpleDateFormat sdfmat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
        Date lastDate = null;
        Date nextDate = null;
        try {
            lastDate = sdf.parse(lastBirthday);
            nextDate = sdf.parse(nextBirthday);
        System.out.println("-------------44------>>"+lastDate);
        System.out.println("------------------->>"+nextDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<Student> studentList = studentService.findByBirthdayBetween(lastDate,nextDate);
        for (Student student: studentList){
            System.out.println(student);
        }

        Integer currentPage = 0;
        int NumberOfElements = 0;//当前页有几条信息
        int TotalPages = 0;//页数
        int pageSize = 10;//每页总数为10条
        int TotalElements = studentList.size();
        int total = TotalElements % pageSize;
        if (total > 0) {
            TotalPages = TotalElements / pageSize + 1;
        } else {
            TotalPages = TotalElements / pageSize;
        }
        System.out.println("num--"+NumberOfElements+"total"+total+"TotalElements"+TotalElements);
        System.out.println("TotalPages--"+TotalPages);
        if(total == 0){
            if(TotalPages == 0){
                studentList = null;
            }else {
                studentList = studentList.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
            }
        }else{
            if(TotalElements > pageSize){
                studentList = studentList.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
            }else {
                studentList = studentList.subList(currentPage,TotalElements);
            }
        }
        if(studentList.size()!=0){
            for (Student student : studentList) {
                System.out.println(student + "----------------lx----------");
            }
        }
        NumberOfElements = studentList.size();
        List<BigInteger> subjectCount = studentService.getSubjectById();
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        request.setAttribute("lastBirthday", lastBirthday);
        request.setAttribute("nextBirthday", nextBirthday);
        request.setAttribute("NumberOfElements", NumberOfElements);
        request.setAttribute("TotalPages", TotalPages);
        request.setAttribute("TotalElements", TotalElements);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("studentList", studentList);

        modelAndView.setViewName("student/studentBirthday");
        return modelAndView;
    }

    @RequestMapping("SearchBirthdayPage")
    public ModelAndView searchBirthdayPage(){
        String lastBirthday = request.getParameter("lastBirthday");
        String nextBirthday = request.getParameter("nextBirthday");
        Integer currentPage = Integer.parseInt(request.getParameter("currentPage"));
        System.out.println(currentPage + "--currentPage--------------lx----------");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //SimpleDateFormat sdfmat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
        Date lastDate = null;
        Date nextDate = null;
        try {
            lastDate = sdf.parse(lastBirthday);
            nextDate = sdf.parse(nextBirthday);
            System.out.println("-------------44------>>"+lastDate);
            System.out.println("------------------->>"+nextDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<Student> studentList1 = studentService.findByBirthdayBetween(lastDate,nextDate);
        List<Student> studentList = null;
        int NumberOfElements = 0;//当前页有几条信息
        int TotalPages = 0;//页数
        int pageSize = 10;//每页总数为10条
        int TotalElements = studentList1.size();
        int total = TotalElements % pageSize;
        System.out.println(total+"-<--------total-----------TotalElements---------->----"+TotalElements);
        if (total > 0) {
            TotalPages = TotalElements/pageSize + 1;
        } else {
            TotalPages = TotalElements/pageSize;
        }
        System.out.println("TotalPages---------------"+TotalPages);

        if (total > 0) {
            TotalPages = TotalElements/pageSize + 1;
        } else {
            TotalPages = TotalElements/pageSize;
        }
        System.out.println("TotalPages---------------"+TotalPages);
        List<BigInteger> subjectCount = studentService.getSubjectById();
        List<BigDecimal> AvgScoreList = studentService.getSubjectAvgScore();
        request.setAttribute("AvgScoreList",AvgScoreList);
        request.setAttribute("subjectCount",subjectCount);
        for (int j = 1; j <= TotalPages; j++) {
            if (total == 0) {
                if (currentPage <= 0) {
                    currentPage = 0;
                    studentList = studentList1.subList((0) * pageSize, pageSize * (0 + 1));
                    for (Student student : studentList1) {
                        System.out.println(student + "----------------lx----------");
                    }
                    System.out.println("------------------<=0-------------------");
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("lastBirthday", lastBirthday);
                    request.setAttribute("nextBirthday", nextBirthday);
                    modelAndView.setViewName("student/studentBirthdaySearchPage");
                }
                if (currentPage >= TotalPages) {
                    studentList = studentList1.subList((currentPage - 1) * pageSize, TotalElements);
                    currentPage = TotalPages - 1;
                    System.out.println("currentPage=pageCount-1;" + currentPage + "/////" + TotalPages);
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("lastBirthday", lastBirthday);
                    request.setAttribute("nextBirthday", nextBirthday);
                    modelAndView.setViewName("student/studentBirthdaySearchPage");

                }
                if (0 < currentPage && currentPage < TotalPages) {
                    studentList = studentList1.subList((currentPage) * pageSize, pageSize * (currentPage + 1));
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("lastBirthday", lastBirthday);
                    request.setAttribute("nextBirthday", nextBirthday);
                    modelAndView.setViewName("student/studentBirthdaySearchPage");

                }
            }else {
                if(currentPage<=0) {
                    currentPage=0;
                    if((currentPage+1) == TotalPages){
                        studentList = studentList1.subList(currentPage,TotalElements);
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("lastBirthday", lastBirthday);
                        request.setAttribute("nextBirthday", nextBirthday);
                        modelAndView.setViewName("student/studentBirthdaySearchPage");
                    }else {
                        studentList = studentList1.subList((0)* pageSize, pageSize*(0+1));
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("lastBirthday", lastBirthday);
                        request.setAttribute("nextBirthday", nextBirthday);
                        modelAndView.setViewName("student/studentBirthdaySearchPage");
                    }
                }
                if(currentPage>=TotalPages){
                    studentList = studentList1.subList((currentPage-1)* pageSize, TotalElements);
                    currentPage=TotalPages-1;
                    System.out.println("currentPage=pageCount-1;"+currentPage+"/////"+TotalPages);
                    NumberOfElements = studentList.size();
                    request.setAttribute("NumberOfElements", NumberOfElements);
                    request.setAttribute("TotalPages", TotalPages);
                    request.setAttribute("TotalElements", TotalElements);
                    request.setAttribute("currentPage", currentPage);
                    request.setAttribute("studentList", studentList);
                    request.setAttribute("lastBirthday", lastBirthday);
                    request.setAttribute("nextBirthday", nextBirthday);
                    modelAndView.setViewName("student/studentBirthdaySearchPage");
                }
                if(0<currentPage&&currentPage<TotalPages) {
                    if(currentPage == (TotalPages-1)){

                        studentList = studentList1.subList((currentPage)* pageSize,TotalElements);
                        System.out.println(studentList+"--------------2");
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("lastBirthday", lastBirthday);
                        request.setAttribute("nextBirthday", nextBirthday);
                        modelAndView.setViewName("student/studentBirthdaySearchPage");
                    }else{
                        studentList = studentList1.subList((currentPage-1)* pageSize, (currentPage)* pageSize);
                        System.out.println(studentList+"--------------2");
                        NumberOfElements = studentList.size();
                        request.setAttribute("NumberOfElements", NumberOfElements);
                        request.setAttribute("TotalPages", TotalPages);
                        request.setAttribute("TotalElements", TotalElements);
                        request.setAttribute("currentPage", currentPage);
                        request.setAttribute("studentList", studentList);
                        request.setAttribute("lastBirthday", lastBirthday);
                        request.setAttribute("nextBirthday", nextBirthday);
                        modelAndView.setViewName("student/studentBirthdaySearchPage");

                    }

                }
            }
        }
        return  modelAndView;

    }


    @RequestMapping("studentAdd")
    public ModelAndView add(){
        modelAndView.setViewName("student/studentAdd");
        return modelAndView;
    }
    @RequestMapping("doStudentAdd")
    public ModelAndView doAdd() throws ParseException {
        String name = request.getParameter("name");
        String code = request.getParameter("code");
        String birthday = request.getParameter("birthday");
        Date date = null;
        if(birthday!=null&&birthday!=""){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        date = sdf.parse(birthday);
        }
        System.out.println("----------"+birthday+"llllllllll"+date);
        String gradeName = request.getParameter("grade");
        String sex = (request.getParameter("sex").equals("M")?"男":"女");
        String subjectName = request.getParameter("subject");
        System.out.println(name+code+birthday+sex+gradeName);
        List<Student> studentList = new ArrayList<Student>();
        Student student = new Student();
        student.setCode(code);
        student.setName(name);
        student.setSex(sex);
        student.setBirthday(date);
        Grade grade = new Grade();
        grade.setGradeName(gradeName);
        student.setGrade(grade);
        List<Subject> subjectList =new ArrayList<Subject>();
        Subject subject =new Subject();
        subject.setName(subjectName);
        subjectList.add(subject);
        student.setSubjectList(subjectList);
        studentList.add(student);
        studentService.save(studentList);
        List<BigInteger> subjectCount = studentService.getSubjectById();
        request.setAttribute("subjectCount",subjectCount);
        modelAndView=showList();
        return modelAndView;
    }

    @RequestMapping("addScore")
    public ModelAndView addScore(){
        Integer id = Integer.parseInt(request.getParameter("id"));
        Student student = studentService.getStudentById(id);
        request.setAttribute("student",student);
        modelAndView.setViewName("student/scoreAdd");
        return modelAndView;
    }
    @RequestMapping("addSubject")
    public ModelAndView addSubject(){
        Integer id = Integer.parseInt(request.getParameter("id"));
        Student student = studentService.getStudentById(id);
        request.setAttribute("student",student);
        modelAndView.setViewName("student/subjectAdd");
        return modelAndView;
    }
    @RequestMapping("update")
    public ModelAndView updateStudent(){
        Integer id = Integer.parseInt(request.getParameter("id"));
        Student student = studentService.getStudentById(id);
        System.out.println("--------------------------------------"+student);
        request.setAttribute("student",student);
        modelAndView.setViewName("student/studentUpdate");
        return modelAndView;
    }
    @RequestMapping("doStudentUpdate")
    public ModelAndView doStudentUpdate()  {
        Integer id = Integer.parseInt(request.getParameter("id"));
        String code = request.getParameter("code");
        String name = request.getParameter("name");
        String birthday = request.getParameter("birthday");
        Date date = null;
        if(birthday!=null&&birthday!=""){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            try {
                date = sdf.parse(birthday);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        System.out.println("id--"+id+"----------"+birthday+"llllllllll"+date);
        String gradeName = request.getParameter("grade");
        String sex = (request.getParameter("sex").equals("M")?"男":"女");
        System.out.println("----------"+sex+"---------------");
        String subjectName = request.getParameter("subject");
        System.out.println("----------"+gradeName+"-gradeName------subjectName--------");
        System.out.println(name+code+birthday+sex+gradeName);
        Student student = new Student();
        student.setId(id);
        student.setCode(code);
        student.setName(name);
        student.setBirthday(date);
        student.setSex(sex);
        Integer grade_id = studentService.queryStudentGrade_id(student.getId());
        studentService.updateGrade(grade_id,gradeName);
        studentService.updateStudent(student);
        modelAndView=showList();
        return modelAndView;
    }
    @RequestMapping("studentDel")
    public ModelAndView deleteStudentById(){
        Integer id = Integer.parseInt(request.getParameter("id"));
        studentService.deleteStudentById(id);
        List<BigInteger> subjectCount = studentService.getSubjectById();
        request.setAttribute("subjectCount",subjectCount);
        modelAndView = showList();
        return modelAndView;
    }

    @RequestMapping("gradeMessage")
    public ModelAndView gradeMessage(){
        List<String> gradeNameList = studentService.getGradeName();
        List<BigInteger> studentNumList = studentService.getstudentNum();
        List<BigDecimal> studentAvgScoreList = studentService.getStudentAvgScore();
        List<Integer> sortNum = new ArrayList<Integer>();
        for (int i=0;i<gradeNameList.size();i++){
            sortNum.add(i,i+1);
        }
        request.setAttribute("gradeNameList",gradeNameList);
        request.setAttribute("studentNumList",studentNumList);
        request.setAttribute("studentAvgScoreList",studentAvgScoreList);
        request.setAttribute("sortNum",sortNum);
        modelAndView.setViewName("student/gradeMessage");
        return modelAndView;
    }
    @RequestMapping("subjectMessage")
    public ModelAndView subjectMessage(){
        List<String> subjectNameList = studentService.getSubjectName();
        List<BigInteger> subjectNumList = studentService.getSubjectNum();
        List<BigDecimal> subjectAvgScoreList = studentService.getSubjectSubjectAvgScore();
        List<Integer> sortNum = new ArrayList<Integer>();
        for (int i=0;i<subjectNameList.size();i++){
            sortNum.add(i,i+1);
        }
        request.setAttribute("subjectNameList",subjectNameList);
        request.setAttribute("subjectNumList",subjectNumList);
        request.setAttribute("subjectAvgScoreList",subjectAvgScoreList);
        request.setAttribute("sortNum",sortNum);
        modelAndView.setViewName("student/subjectMessage");
        return modelAndView;
    }
    @RequestMapping("subjectAdd")
    public ModelAndView subjectAdd(){
        modelAndView.setViewName("student/subjectAdd");
        return modelAndView;
    }

    @RequestMapping("doSubjectAdd")
    public ModelAndView doSubjectAdd(){
        String subjectName = request.getParameter("name");
        System.out.println("name----"+subjectName);
        Subject subject = new Subject();
        subject.setName(subjectName);
        studentService.saveSubject(subject);
        return subjectMessage();
    }
    @RequestMapping("subjectDel")
    public ModelAndView deleteSubjectById(){
        Integer id = Integer.parseInt(request.getParameter("id"));
        studentService.deleteSubjectById(id);
        List<BigInteger> subjectCount = studentService.getSubjectById();
        request.setAttribute("subjectCount",subjectCount);
        modelAndView = showList();
        return modelAndView;
    }

    @RequestMapping("gradeAdd")
    public ModelAndView gradeAdd(){
        modelAndView.setViewName("student/gradeAdd");
        return modelAndView;
    }

    @RequestMapping("doGradeAdd")
    public ModelAndView doGradeAdd(){
        String gradeName = request.getParameter("name");
        System.out.println("gradename----"+gradeName);
        Grade grade = new Grade();
        grade.setGradeName(gradeName);
        studentService.saveGrade(grade);
        return gradeMessage();
    }
    @RequestMapping("gradeDel")
    public ModelAndView gradeDel(){
        String gradeName = request.getParameter("gradename");
        List<Student> studentList = studentService.getStudentsByGradeName(gradeName);
        for (Student student:studentList) {
            System.out.println("-----------某班的学生----------"+student);
            studentService.deleteStudentById(student.getId());
            List<Integer> integerList = studentService.getSubjectByStudentId(student.getId());
            for (Integer id:integerList) {
                studentService.deleteSubjectById(id);
                System.out.println("-------某班的学生"+""+"--------所选课程id-------------"+id);
            }
        }
        studentService.deleteGradeByName(gradeName);
        return gradeMessage();
    }
    @RequestMapping("gradeUpdate")
    public ModelAndView gradeUpdate(){
        String gradeName = request.getParameter("gradeName");
        System.out.println("gradeName----->"+gradeName);

        return modelAndView;
    }

}
