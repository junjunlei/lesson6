package com.biz.lesson.vo;

/**
 * Created by defei on 1/13/17.
 */
public interface I18nName {

    /**
     * Get name of system locale
     */
    String getName();

    /**
     * Get English Name
     */
    String getNameEn();
}
