package com.biz.lesson.business.config;

/**
 * 配置观察者 
 */
public interface ConfigWatcher {

	void reloadConfig();
}
