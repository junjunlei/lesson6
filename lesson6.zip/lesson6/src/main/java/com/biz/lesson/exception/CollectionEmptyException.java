package com.biz.lesson.exception;

public class CollectionEmptyException extends RuntimeException {

    private static final long serialVersionUID = 3283618842915686646L;

    public CollectionEmptyException() {
        super();
    }

    
    

}
