package com.biz.lesson.dao.user;


public interface ResourceDao {

}
